#!/bin/bash
# Copy this file to my-supabase-keys.sh (remove the .example) and fill in
# your real values there. my-supabase-keys.sh is NEVER shipped in updates,
# so your real keys survive every future zip download — only this
# .example template gets replaced.
#
#   cp my-supabase-keys.sh.example my-supabase-keys.sh
#   (then edit my-supabase-keys.sh with your real values)

export HADAM_AUTH_DRIVER=supabase
export SUPABASE_URL="https://leodrmnlmbthyixehfve.supabase.co"
export SUPABASE_ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxlb2RybW5sbWJ0aHlpeGVoZnZlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODM0MzUzNTMsImV4cCI6MjA5OTAxMTM1M30.8MTurGtY-LP8cBzk6WNhvyfI2CBtpJoie7Wl63OUQTg"
export SUPABASE_SERVICE_ROLE_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imxlb2RybW5sbWJ0aHlpeGVoZnZlIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc4MzQzNTM1MywiZXhwIjoyMDk5MDExMzUzfQ.e52Bfus4tvJKwio5gYPtNux2RK6mAKl5BZF2RFIsaFs"

export RESEND_API_KEY="re_dvZVp7fF_C1VvDEFoW6u6qatDc5kyq4eG"
export FROM_EMAIL="onboarding@resend.dev"